export const projects = [
  {
    title: "Project 1",
    description: "Description of project 1. This is a brief overview of what the project does and the technologies used.",
    image: "/project1.jpg",
    demoLink: "#",
    githubLink: "#",
  },
  {
    title: "Project 2",
    description: "Description of project 2. Highlighting the main features and the problem it solves for users.",
    image: "/project2.jpg",
    demoLink: "#",
    githubLink: "#",
  },
  {
    title: "Project 3",
    description: "Description of project 3. Explaining the technical challenges overcome and the impact of the project.",
    image: "/project3.jpg",
    demoLink: "#",
    githubLink: "#",
  },
  {
    title: "Project 4",
    description: "Description of project 4. Showcasing your skills and the unique aspects of this particular project.",
    image: "/project4.jpg",
    demoLink: "#",
    githubLink: "#",
  },
];

